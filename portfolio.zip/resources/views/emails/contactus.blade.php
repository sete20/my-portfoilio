<h2>Hello  Iam {{$name}} </h2>
</hr>
<p>You received an email from : {{$email}} </p>
<br>
<p>I Contact With You For This Subject : {{$subject}}</p>
<br>
<p>Message: {{$messages}}</p>
<br>
<p>Email: {{$email}} </p>