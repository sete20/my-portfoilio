<h2>Hello  Iam <?php echo e($name); ?> </h2>
</hr>
<p>You received an email from : <?php echo e($email); ?> </p>
<br>
<p>I Contact With You For This Subject : <?php echo e($subject); ?></p>
<br>
<p>Message: <?php echo e($messages); ?></p>
<br>
<p>Email: <?php echo e($email); ?> </p><?php /**PATH C:\xampp\htdocs\Laravelprojects\portfolio\resources\views/emails/contactus.blade.php ENDPATH**/ ?>